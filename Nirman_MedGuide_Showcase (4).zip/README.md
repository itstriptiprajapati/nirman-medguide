# Nirman MedGuide — Local Website Demo

A polished Flask + SQLite student prototype for prescription text review, public medicine reference lookups, medicine list management, schedule tracking, and best-effort browser reminders.

## Run on Windows with VS Code
1. Extract this ZIP to a folder.
2. Open the folder in VS Code.
3. Open Terminal → New Terminal.
4. Optional virtual environment:
   `py -m venv .venv`
   `.\.venv\Scripts\Activate.ps1`
5. Install dependencies:
   `python -m pip install -r requirements.txt`
6. Start the website:
   `python app.py`
7. In your browser open: `http://127.0.0.1:5000`

If `py` is unavailable, use `python` for the virtual environment command. If PowerShell blocks activation, you can skip the virtual environment and install packages for your current Python.

## OCR setup
The app can still be used without OCR: type/paste text manually. To enable image OCR:
- Install the Tesseract OCR application for Windows.
- Ensure the Tesseract executable is available on PATH.
- Install the Python dependencies from requirements.txt.
- Restart the app after installation.

## Features
- Custom responsive dashboard and navigation
- Prescription image upload (max 8 MB) and optional OCR text extraction
- Save reviewed prescription text as notes
- RxNorm public medicine-name terminology lookup
- openFDA public drug-label lookup (US label coverage)
- Add/delete medicine records
- SQLite persistence for medicines, schedules, notes, and dose logs
- Mark scheduled entries as taken
- Best-effort browser notifications while the page is open and permission is granted

## Honest limitations
- OCR does not safely interpret uncertain handwriting or verify dose instructions.
- RxNorm/openFDA are US public data sources and may not cover Indian brands or products.
- The reminder checker works only while the website is open in the browser. It is not a guaranteed alarm or background notification.
- This is a local demo with no login, cloud sync, encryption, or medical-grade privacy controls.
- Do not use real identifiable patient records in the demo. Use fictional test data.
- Never diagnose, prescribe, change a dose, or recommend stopping treatment from this app.

## Before any public deployment
Change the Flask secret key, disable debug mode, add authentication and access controls, secure uploads, implement consent and deletion policies, use HTTPS, protect patient data, and have the medical content and workflows reviewed by qualified professionals.
