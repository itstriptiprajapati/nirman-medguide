async function enableReminders(){
  if(!("Notification" in window)){alert("This browser does not support desktop notifications.");return;}
  const permission = await Notification.requestPermission();
  const status = document.getElementById("notify-status");
  if(status) status.textContent = permission === "granted" ? "Browser notifications enabled while this page is open." : "Notifications were not enabled.";
}
async function pollReminders(){
  try{
    if(!("Notification" in window) || Notification.permission !== "granted") return;
    const res = await fetch("/api/reminders");
    const items = await res.json();
    const now = new Date();
    const hh = String(now.getHours()).padStart(2,"0");
    const mm = String(now.getMinutes()).padStart(2,"0");
    const todayKey = now.toISOString().slice(0,10);
    items.forEach(item=>{
      if(item.time === `${hh}:${mm}`){
        const key = `medguide-notified-${todayKey}-${item.id}`;
        if(!sessionStorage.getItem(key)){
          new Notification("Nirman MedGuide reminder", {
            body: `Scheduled medicine: ${item.name}. Follow only the instructions confirmed by your healthcare professional.`,
            tag: key
          });
          sessionStorage.setItem(key,"1");
        }
      }
    });
  }catch(e){/* reminder polling is best-effort */}
}
setInterval(pollReminders, 30000);
