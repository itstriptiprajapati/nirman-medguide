from flask import Flask, render_template, request, redirect, url_for, flash, jsonify
import sqlite3
from pathlib import Path
from datetime import datetime, date
import requests
from werkzeug.utils import secure_filename

try:
    from PIL import Image
    import pytesseract
    OCR_AVAILABLE = True
except Exception:
    OCR_AVAILABLE = False

BASE_DIR = Path(__file__).resolve().parent
DB_PATH = BASE_DIR / "medguide.db"
UPLOAD_DIR = BASE_DIR / "uploads"
UPLOAD_DIR.mkdir(exist_ok=True)
ALLOWED_EXTENSIONS = {"png", "jpg", "jpeg", "webp"}

app = Flask(__name__)
app.secret_key = "change-this-before-deploying"
app.config["MAX_CONTENT_LENGTH"] = 8 * 1024 * 1024
app.config["UPLOAD_FOLDER"] = str(UPLOAD_DIR)

def db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    with db() as conn:
        conn.execute("""CREATE TABLE IF NOT EXISTS medicines(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            notes TEXT DEFAULT '',
            created_at TEXT NOT NULL
        )""")
        conn.execute("""CREATE TABLE IF NOT EXISTS schedules(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            medicine_id INTEGER,
            medicine_name TEXT NOT NULL,
            schedule_date TEXT NOT NULL,
            dose_time TEXT NOT NULL,
            instructions TEXT DEFAULT '',
            created_at TEXT NOT NULL,
            FOREIGN KEY(medicine_id) REFERENCES medicines(id)
        )""")
        conn.execute("""CREATE TABLE IF NOT EXISTS dose_log(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            schedule_id INTEGER NOT NULL,
            taken_date TEXT NOT NULL,
            taken_at TEXT NOT NULL,
            UNIQUE(schedule_id, taken_date)
        )""")
        conn.execute("""CREATE TABLE IF NOT EXISTS notes(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT NOT NULL,
            body TEXT NOT NULL,
            created_at TEXT NOT NULL
        )""")
init_db()

def allowed_file(filename):
    return "." in filename and filename.rsplit(".", 1)[1].lower() in ALLOWED_EXTENSIONS

def medicine_rows():
    with db() as conn:
        return conn.execute("SELECT * FROM medicines ORDER BY id DESC").fetchall()

def schedules_for(day=None):
    with db() as conn:
        if day:
            return conn.execute("SELECT * FROM schedules WHERE schedule_date=? ORDER BY dose_time", (str(day),)).fetchall()
        return conn.execute("SELECT * FROM schedules ORDER BY schedule_date DESC,dose_time").fetchall()

def taken(schedule_id, day):
    with db() as conn:
        return conn.execute("SELECT 1 FROM dose_log WHERE schedule_id=? AND taken_date=?", (schedule_id, str(day))).fetchone() is not None

@app.context_processor
def inject_globals():
    return {"today": date.today().isoformat(), "year": datetime.now().year}

@app.route("/")
def index():
    meds = medicine_rows()
    today_schedules = schedules_for(date.today())
    completed = sum(1 for s in today_schedules if taken(s["id"], date.today()))
    return render_template("index.html", meds=meds, schedules=today_schedules, completed=completed,
                           total=len(today_schedules), med_count=len(meds),
                           dose_status={s["id"]: taken(s["id"], date.today()) for s in today_schedules})

@app.route("/prescription", methods=["GET", "POST"])
def prescription():
    extracted = ""
    filename = None
    if request.method == "POST":
        upload = request.files.get("prescription")
        manual = request.form.get("manual_text", "").strip()
        if upload and upload.filename:
            if not allowed_file(upload.filename):
                flash("Please upload a PNG, JPG, JPEG, or WEBP image.", "error")
            else:
                safe_name = secure_filename(upload.filename)
                # unique-ish name prevents accidental overwrite
                stored_name = datetime.now().strftime("%Y%m%d%H%M%S_") + safe_name
                path = UPLOAD_DIR / stored_name
                upload.save(path)
                filename = stored_name
                if OCR_AVAILABLE:
                    try:
                        extracted = pytesseract.image_to_string(Image.open(path).convert("RGB"))
                    except Exception:
                        flash("OCR could not read this image. You can still type the text manually.", "warning")
                else:
                    flash("OCR isn't configured yet. You can still type or paste the text below.", "warning")
        if manual:
            extracted = manual
        if request.form.get("save_note") == "yes" and extracted.strip():
            title = request.form.get("note_title", "Prescription review").strip() or "Prescription review"
            with db() as conn:
                conn.execute("INSERT INTO notes(title,body,created_at) VALUES(?,?,?)",
                             (title, extracted, datetime.now().isoformat(timespec="seconds")))
            flash("Reviewed text saved to Notes.", "success")
    return render_template("prescription.html", extracted=extracted, filename=filename, ocr_available=OCR_AVAILABLE)

@app.route("/medicines", methods=["GET", "POST"])
def medicines():
    if request.method == "POST":
        name = request.form.get("name", "").strip()
        notes = request.form.get("notes", "").strip()
        if name:
            with db() as conn:
                conn.execute("INSERT INTO medicines(name,notes,created_at) VALUES(?,?,?)",
                             (name, notes, datetime.now().isoformat(timespec="seconds")))
            flash("Medicine saved.", "success")
        else:
            flash("Enter a medicine name first.", "error")
        return redirect(url_for("medicines"))
    return render_template("medicines.html", meds=medicine_rows())

@app.post("/medicines/<int:med_id>/delete")
def delete_medicine(med_id):
    with db() as conn:
        conn.execute("DELETE FROM schedules WHERE medicine_id=?", (med_id,))
        conn.execute("DELETE FROM medicines WHERE id=?", (med_id,))
    flash("Medicine and its linked schedules deleted.", "success")
    return redirect(url_for("medicines"))

@app.route("/library", methods=["GET", "POST"])
def library():
    query = ""
    matches = []
    labels = []
    error = ""
    if request.method == "POST":
        query = request.form.get("query", "").strip()
        action = request.form.get("action", "names")
        if query:
            try:
                if action == "labels":
                    resp = requests.get("https://api.fda.gov/drug/label.json",
                        params={"search": f'openfda.brand_name:"{query}" OR openfda.generic_name:"{query}"', "limit": 3},
                        timeout=8)
                    if resp.status_code == 404:
                        labels = []
                    else:
                        resp.raise_for_status()
                        labels = resp.json().get("results", [])
                else:
                    resp = requests.get("https://rxnav.nlm.nih.gov/REST/drugs.json",
                                        params={"name": query}, timeout=8)
                    resp.raise_for_status()
                    groups = resp.json().get("drugGroup", {}).get("conceptGroup", []) or []
                    seen = set()
                    for group in groups:
                        for item in group.get("conceptProperties", []) or []:
                            name = item.get("name")
                            if name and name not in seen:
                                seen.add(name); matches.append(name)
                    matches = matches[:15]
            except Exception:
                error = "The public reference service could not be reached. Check your internet connection and try again."
    return render_template("library.html", query=query, matches=matches, labels=labels, error=error)

@app.route("/scheduler", methods=["GET", "POST"])
def scheduler():
    meds = medicine_rows()
    if request.method == "POST":
        med_id_raw = request.form.get("medicine_id", "").strip()
        manual_name = request.form.get("manual_name", "").strip()
        day = request.form.get("schedule_date", "").strip()
        clock = request.form.get("dose_time", "").strip()
        instructions = request.form.get("instructions", "").strip()
        med_id = None
        name = manual_name
        if med_id_raw:
            try:
                med_id = int(med_id_raw)
                with db() as conn:
                    row = conn.execute("SELECT name FROM medicines WHERE id=?", (med_id,)).fetchone()
                if row: name = row["name"]
            except ValueError:
                med_id = None
        try:
            datetime.strptime(day, "%Y-%m-%d")
            datetime.strptime(clock, "%H:%M")
            if not name:
                raise ValueError("Choose a saved medicine or type a name.")
            with db() as conn:
                conn.execute("""INSERT INTO schedules(medicine_id,medicine_name,schedule_date,dose_time,instructions,created_at)
                    VALUES(?,?,?,?,?,?)""", (med_id, name, day, clock, instructions, datetime.now().isoformat(timespec="seconds")))
            flash("Schedule entry added. Browser reminders work while this page is open and notifications are allowed.", "success")
        except ValueError as exc:
            flash(str(exc) or "Please check the date and time.", "error")
        return redirect(url_for("scheduler"))
    all_items = schedules_for()
    status = {s["id"]: taken(s["id"], s["schedule_date"]) for s in all_items}
    return render_template("scheduler.html", meds=meds, schedules=all_items, status=status)

@app.post("/scheduler/<int:schedule_id>/taken")
def mark_taken(schedule_id):
    with db() as conn:
        row = conn.execute("SELECT schedule_date FROM schedules WHERE id=?", (schedule_id,)).fetchone()
        if row:
            conn.execute("INSERT OR IGNORE INTO dose_log(schedule_id,taken_date,taken_at) VALUES(?,?,?)",
                         (schedule_id, row["schedule_date"], datetime.now().isoformat(timespec="seconds")))
    flash("Dose status updated.", "success")
    return redirect(request.referrer or url_for("scheduler"))

@app.post("/scheduler/<int:schedule_id>/delete")
def delete_schedule(schedule_id):
    with db() as conn:
        conn.execute("DELETE FROM dose_log WHERE schedule_id=?", (schedule_id,))
        conn.execute("DELETE FROM schedules WHERE id=?", (schedule_id,))
    flash("Schedule entry deleted.", "success")
    return redirect(url_for("scheduler"))

@app.route("/notes", methods=["GET", "POST"])
def notes():
    if request.method == "POST":
        title = request.form.get("title", "").strip() or "Untitled note"
        body = request.form.get("body", "").strip()
        if body:
            with db() as conn:
                conn.execute("INSERT INTO notes(title,body,created_at) VALUES(?,?,?)",
                             (title, body, datetime.now().isoformat(timespec="seconds")))
            flash("Note saved.", "success")
        else:
            flash("Write something before saving.", "error")
        return redirect(url_for("notes"))
    with db() as conn:
        rows = conn.execute("SELECT * FROM notes ORDER BY id DESC").fetchall()
    return render_template("notes.html", notes=rows)

@app.post("/notes/<int:note_id>/delete")
def delete_note(note_id):
    with db() as conn:
        conn.execute("DELETE FROM notes WHERE id=?", (note_id,))
    flash("Note deleted.", "success")
    return redirect(url_for("notes"))

@app.route("/api/reminders")
def api_reminders():
    rows = schedules_for(date.today())
    result = []
    for s in rows:
        if not taken(s["id"], date.today()):
            result.append({"id": s["id"], "name": s["medicine_name"], "time": s["dose_time"],
                           "instructions": s["instructions"]})
    return jsonify(result)

@app.route("/health")
def health():
    return jsonify({"status": "ok", "app": "Nirman MedGuide"})

@app.errorhandler(413)
def too_large(_):
    flash("Image is too large. Please use an image under 8 MB.", "error")
    return redirect(url_for("prescription"))

if __name__ == "__main__":
    app.run(debug=True, host="127.0.0.1", port=5000)
